const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 9876;

app.use(bodyParser.json());
app.use(cors());

const isPrime = (num) => {
  for (let i = 2, sqrt = Math.sqrt(num); i <= sqrt; i++) if (num % i === 0) return false;
  return num > 1;
};

const generateFibonacci = (n) => {
  let fib = [0, 1];
  for (let i = 2; i < n; i++) fib[i] = fib[i - 1] + fib[i - 2];
  return fib;
};

const generateEvenNumbers = (n) => {
  return Array.from({ length: n }, (_, i) => i * 2 + 2);
};

const generateRandomNumbers = (n) => {
  return Array.from({ length: n }, () => Math.floor(Math.random() * 100));
};

app.get('/numbers/:type', (req, res) => {
  const { type } = req.params;
  let numbers;

  switch (type) {
    case 'p':
      numbers = Array.from({ length: 10 }, (_, i) => i + 1).filter(isPrime);
      break;
    case 'f':
      numbers = generateFibonacci(10);
      break;
    case 'e':
      numbers = generateEvenNumbers(10);
      break;
    case 'r':
      numbers = generateRandomNumbers(10);
      break;
    default:
      return res.status(400).json({ error: 'Invalid type' });
  }

  const sum = numbers.reduce((acc, num) => acc + num, 0);
  const average = sum / numbers.length;

  res.json({ average, numbers });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
